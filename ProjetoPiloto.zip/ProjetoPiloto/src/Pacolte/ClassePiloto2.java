package Pacolte;

public class ClassePiloto2 
{
 public static void main (String args[])
 {
	 //println
	 System.out.println("Olá mundo 1");
	 //print
	 System.out.print("Olá, mundo!");
	 //printf
	int idade = 12;
	String nome = "Maria";
	boolean clt = true;
	double salario = 1518.21;
	float valeRefeicao = 400.5F;
	System.out.printf("Nome: %s\n", nome);
	System.out.printf("Idade: %d\n", idade);
 } // Fim corpo main
}
